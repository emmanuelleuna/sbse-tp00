```bash
# Step1 : Install depenses
pip install -r requirements.txt

# Step 2 : Run the program
python main.py