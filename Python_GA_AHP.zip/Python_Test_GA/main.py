from GA_vand import *
def main():
    finalists, finalists_muted = genetic_algorithm()
    return finalists, finalists_muted

if __name__ == "__main__":
    main()